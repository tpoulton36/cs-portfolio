package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class HashController {

    /**
     * Endpoint to return SHA-256 hash of the input string
     * Example usage: https://localhost:8443/hash?input=YourName123
     * 
     * @param input The input string to hash
     * @return The SHA-256 hash of the input
     */
    @GetMapping("/hash")
    public String getChecksum(@RequestParam String input) {
        try {
            // Create SHA-256 MessageDigest instance
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Compute the hash of the input string
            byte[] hashBytes = digest.digest(input.getBytes());

            // Convert the hash bytes to hexadecimal format
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            // Return the hex hash as a response
            return "Original input: " + input + "\nSHA-256 hash: " + hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            return "Error: SHA-256 algorithm not found.";
        }
    }
}
